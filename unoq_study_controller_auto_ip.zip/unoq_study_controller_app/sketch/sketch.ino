// Arduino UNO Q MCU (STM32): 16x2 I2C LCD and D9 vibration module.
// Linux/Python passes (state_id, DozeTime) by Bridge RPC.
// 0=Empty, 1=Study, 2=Dozzy.
#include <Wire.h>
#include <DIYables_LCD_I2C.h>
#include <Arduino_RouterBridge.h>
#include <math.h>
#include <string.h>

const int VIBRATION_PIN = 9;
const uint8_t LCD_ADDRESS = 0x27;   // Keep the address that worked before; try 0x3F only if necessary.
DIYables_LCD_I2C lcd(LCD_ADDRESS, 16, 2);

const unsigned long CLEAR_DELAY_MS = 3000UL; // Study/Empty for 3 seconds -> stop motor
const unsigned long SIGNAL_TIMEOUT_MS = 5000UL; // No updates 5 seconds -> motor OFF
const unsigned long LCD_PERIOD_MS = 200UL;

int currentState = -1;
float currentDoze = 0.0f;
unsigned long stateBeganMs = 0;
unsigned long lastMessageMs = 0;
unsigned long lastLcdMs = 0;
bool receivedAny = false;
bool motorOn = false;
char cachedRow0[17] = "";
char cachedRow1[17] = "";

// `provide_safe` invokes this callback from the main sketch context.
// Keep it short; LCD and motor operations belong in loop().
int set_study_status(int stateId, float dozeSeconds) {
  if (stateId < 0 || stateId > 2) return 0;
  if (!isfinite(dozeSeconds) || dozeSeconds < 0.0f) return 0;
  const unsigned long now = millis();
  if (!receivedAny || currentState != stateId) {
    currentState = stateId;
    stateBeganMs = now;
  }
  currentDoze = (stateId == 2) ? dozeSeconds : 0.0f;
  lastMessageMs = now;
  receivedAny = true;
  return 1;
}

void renderLine(int row, const char *text, char *cache) {
  char padded[17];
  memset(padded, ' ', 16);
  padded[16] = '\0';
  for (int i = 0; i < 16 && text[i] != '\0'; ++i) padded[i] = text[i];
  if (memcmp(cache, padded, 16) != 0) {
    lcd.setCursor(0, row);
    lcd.print(padded);
    memcpy(cache, padded, 17);
  }
}

void setup() {
  digitalWrite(VIBRATION_PIN, LOW);
  pinMode(VIBRATION_PIN, OUTPUT);
  Wire.begin();
  lcd.init();
  lcd.backlight();
  renderLine(0, "Waiting for MQTT", cachedRow0);
  renderLine(1, "Doze: 0.0s", cachedRow1);

  Bridge.begin();
  Bridge.provide_safe("set_study_status", set_study_status);
}

void loop() {
  const unsigned long now = millis();
  const bool signalOK = receivedAny && (now - lastMessageMs <= SIGNAL_TIMEOUT_MS);

  bool wantMotor = motorOn;
  if (!signalOK) {
    wantMotor = false;  // FAIL SAFE: do not vibrate forever if MQTT / Bridge is lost.
  } else if (currentState == 2) {
    wantMotor = currentDoze > 10.0f; // Strictly greater than 10 seconds.
  } else if (now - stateBeganMs >= CLEAR_DELAY_MS) {
    wantMotor = false; // Study or Empty continuously for >= 3s.
  }

  if (wantMotor != motorOn) {
    motorOn = wantMotor;
    digitalWrite(VIBRATION_PIN, motorOn ? HIGH : LOW);
  }

  if (now - lastLcdMs >= LCD_PERIOD_MS) {
    lastLcdMs = now;
    char line0[17];
    char line1[17];
    if (!signalOK) {
      snprintf(line0, sizeof(line0), receivedAny ? "No Signal" : "Waiting for MQTT");
      snprintf(line1, sizeof(line1), "Doze: 0.0s");
    } else {
      const char *name = (currentState == 0) ? "Empty" :
                         (currentState == 1) ? "Study" : "Dozzy";
      snprintf(line0, sizeof(line0), "State: %s", name);
      float displaySeconds = currentDoze;
      if (displaySeconds > 9999.9f) displaySeconds = 9999.9f;
      snprintf(line1, sizeof(line1), "Doze: %.1fs", (double)displaySeconds);
    }
    renderLine(0, line0, cachedRow0);
    renderLine(1, line1, cachedRow1);
  }
  delay(20);
}
