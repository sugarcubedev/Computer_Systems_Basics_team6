# UNO Q Study Controller

This Arduino App Lab project runs on the UNO Q. The Python side subscribes to MQTT messages from the Raspberry Pi; the MCU side controls a 16x2 I2C LCD and D9 vibration module using Bridge RPC.

## Existing wiring (do not change if your earlier LCD and motor test succeeded)
- Motor module IN -> D9; VCC -> 5V breadboard rail; GND -> GND rail
- LCD SDA -> D20; SCL -> D21; VCC -> 5V rail; GND -> GND rail
- See your original wiring safety and voltage-compatibility notes before changing connections.

## Install and run with Arduino App Lab
1. Import this entire application folder or its ZIP in App Lab. Alternatively create a new App, replace `python/main.py` and `sketch/sketch.ino`, and add libraries `Arduino_RouterBridge` and `DIYables LCD I2C` in Sketch Libraries.
2. The default `DEFAULT_BROKER = "auto"` detects the UNO Q host address from inside the App Lab container, so switching Wi-Fi usually requires no editing on the UNO Q. If auto-discovery fails, set `DEFAULT_BROKER` to the current UNO Q LAN IP (from `hostname -I`).
3. Set `DEFAULT_MODE = "control"` (default), press Run and view **Console -> Main (Python)**.
4. The Mosquitto broker must be running on UNO Q and Raspberry Pi must be connected to it. Topic: `student/monitor`.

## Run modes
- `control`: real MQTT -> RPC -> LCD + motor (default in App Lab).
- `mqtt-test`: subscribe and print MQTT messages only; do not command LCD or motor.
- `demo`: sends internally generated statuses to LCD + motor without Raspberry Pi or MQTT.

App Lab starts `python/main.py` without extra CLI args. For App Lab, edit `DEFAULT_MODE` at the top of `python/main.py` to select a mode.

From the UNO Q Linux terminal, MQTT-only mode works with a normal Python environment containing `paho-mqtt`:
```
python3 -m pip install --user 'paho-mqtt>=2.1,<3'  # Only if already allowed by Python environment
python3 python/main.py --mode mqtt-test --broker 127.0.0.1
```
If system Python refuses pip due to managed environment, create a venv or use `sudo apt install python3-paho-mqtt` if the apt version supports callback API v2. The existing `mosquitto_sub -h 127.0.0.1 -t student/monitor -v` command is an alternative that needs no Python packages.

## Manual MQTT scenarios (from UNO Q Linux terminal)
Run the App Lab app in control mode and in a **second terminal** publish:
```
mosquitto_pub -h 127.0.0.1 -t student/monitor -m '{"StudentState":"Dozzy","DozeTime":10.1}'
```
The motor should vibrate and the LCD display `State: Dozzy` and `Doze: 10.1s`.
Then send Study and wait 3 seconds:
```
mosquitto_pub -h 127.0.0.1 -t student/monitor -m '{"StudentState":"Study","DozeTime":0.0}'
```
**Important:** The App receives the message once. If Raspberry Pi is not periodically sending it, the MCU automatically stops the motor after 5 seconds without RPC. To test the 3-second transition reliably without Pi, use `DEFAULT_MODE = "demo"` (App Lab), which cycles through Empty, Study, Dozzy and Study and sends updates every half-second.

## State behavior
| State | LCD line 1 | LCD line 2 | Motor |
|---|---|---|---|
| Empty | State: Empty | Doze: 0.0s | OFF after 3s of Empty |
| Study | State: Study | Doze: 0.0s | OFF after 3s of Study |
| Dozzy | State: Dozzy | Doze: X.Xs | ON iff DozeTime > 10.0s |

After 5 seconds without a Bridge status update, motor stops and LCD shows `No Signal`, as a fail-safe.

## Troubleshooting
- `MQTT connected` but no values: check Raspberry Pi topic `student/monitor` and broker IP.
- `[BRIDGE] Failed`: install `Arduino_RouterBridge`, ensure sketch uploaded, and inspect App Lab Start-up console.
- LCD no text: use the previously working LCD address in `sketch/sketch.ino` (default `0x27`).
- App Lab cannot find a library: install it from Sketch Libraries and rerun, or adjust `sketch/sketch.yaml` version to the version installed in App Lab.
- If MQTT messages appear in a Linux terminal but not inside App Lab, its Python runtime may have a separate network; check `DEFAULT_BROKER` and network reachability from App Lab.

## Changing Wi-Fi or network
- App Lab controller `DEFAULT_BROKER = "auto"`: picks the Uno Q host gateway on the Docker network. Check the `[MQTT]` log to see the detected address; it may be `172.19.0.1` and this is **normal** inside App Lab.
- Raspberry Pi sender: use the board's current Wi-Fi IP (`hostname -I`, e.g. `192.168.45.142`) in `--mqtt-host`. A different Wi-Fi can allocate a different IP.
- MQTT Broker must listen on all relevant network interfaces; configuration `listener 1883 0.0.0.0` handles this on a trusted LAN.
- If `auto` fails in App Lab, set `DEFAULT_BROKER` to the LAN IP from `hostname -I`, then restart the App.
- IMPORTANT: `127.0.0.1` is correct for a plain UNO Q host terminal but NOT for App Lab's isolated Python container.
