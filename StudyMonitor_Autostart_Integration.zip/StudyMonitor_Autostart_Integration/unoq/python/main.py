"""UNO Q App Lab: MQTT -> Bridge -> MCU LCD/vibration + Linux CSV logging.

CSV is created and written by the UNO Q Linux/Python side.
The MCU exposes getter functions; Linux reads the MCU's current stored values
through Bridge and writes those returned values to study_log.csv.

Required files in the App Lab app:
  python/main.py            (this file)
  python/requirements.txt   (must contain: paho-mqtt)
  sketch/sketch.ino         (provides set_study_status / set_monitor_phase / read_* via Bridge)
"""

import argparse
import csv
import json
import math
import os
import socket
import struct
import sys
import threading
import time
from datetime import datetime

try:
    import paho.mqtt.client as mqtt
except ImportError:
    print(
        "[ERROR] paho-mqtt is not installed. "
        "Add a line 'paho-mqtt' to python/requirements.txt and restart the app.",
        flush=True,
    )
    raise

DEFAULT_MODE = os.environ.get("STUDY_MODE", "control")      # control | mqtt-test | demo
DEFAULT_BROKER = os.environ.get("MQTT_BROKER", "auto")      # "auto" or an IP like 192.168.0.10
DEFAULT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
DEFAULT_TOPIC = os.environ.get("MQTT_TOPIC", "student/monitor")

CSV_INTERVAL = 1.0
STALE_SECONDS = 3.0
BRIDGE_TIMEOUT = 3

STATE_IDS = {"Empty": 0, "Study": 1, "Dozzy": 2}
ID_STATES = {value: key for key, value in STATE_IDS.items()}
# Stage 0 reserved for MCU waiting; stages are set by Raspberry Pi messages.
PHASE_IDS = {'STARTING': 1, 'WAIT_FACE': 2, 'CALIBRATING': 3,
             'MONITORING': 4, 'CAMERA_ERROR': 5}


def pick_csv_path():
    preferred = os.environ.get("CSV_PATH") or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "study_log.csv"
    )
    folder = os.path.dirname(preferred) or "."
    if os.access(folder, os.W_OK):
        return preferred
    fallback = os.path.join("/tmp", "study_log.csv")
    print(f"[CSV] {folder} is not writable; using {fallback}", flush=True)
    return fallback


def _default_gateway():
    try:
        with open("/proc/net/route", "r", encoding="ascii") as routes:
            for line in list(routes)[1:]:
                cols = line.split()
                if len(cols) >= 3 and cols[1] == "00000000":
                    return socket.inet_ntoa(struct.pack("<L", int(cols[2], 16)))
    except (OSError, ValueError) as exc:
        print(f"[MQTT] Gateway discovery failed: {exc}", flush=True)
    return None


def _port_open(host, port, timeout=1.0):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def resolve_broker(host, port):
    if host != "auto":
        return host

    candidates = []
    for name in ("HOST_IP",):
        value = os.environ.get(name)
        if value:
            candidates.append(value)
    gateway = _default_gateway()
    if gateway:
        candidates.append(gateway)
    try:
        candidates.append(socket.gethostbyname("host.docker.internal"))
    except OSError:
        pass
    candidates.append("127.0.0.1")

    seen = []
    for ip in candidates:
        if ip in seen:
            continue
        seen.append(ip)
        if _port_open(ip, port):
            print(f"[MQTT] Broker reachable at {ip}:{port}", flush=True)
            return ip
        print(f"[MQTT] No broker at {ip}:{port}", flush=True)

    fallback = seen[0]
    print(
        f"[MQTT] No broker answered. Will keep retrying {fallback}:{port}. "
        "Check that mosquitto listens on 0.0.0.0 (not only localhost) "
        "and allows anonymous clients, or set MQTT_BROKER.",
        flush=True,
    )
    return fallback


def parse_payload(payload):
    """Accept v4.1 monitoring JSON and optional new calibration progress fields.

    Backward compatible: packets without SystemStatus are ordinary monitoring.
    """
    obj = json.loads(payload)
    if not isinstance(obj, dict):
        raise ValueError('Payload must be a JSON object')
    state = obj.get('StudentState')
    if state not in STATE_IDS:
        raise ValueError(f'Unknown StudentState: {state!r}')
    try:
        seconds = float(obj.get('DozeTime', 0) or 0)
    except (TypeError, ValueError) as exc:
        raise ValueError('DozeTime must be numeric') from exc
    if not math.isfinite(seconds) or seconds < 0:
        raise ValueError('Invalid DozeTime')
    if state != 'Dozzy':
        seconds = 0.0

    phase_name = obj.get('SystemStatus')
    if phase_name is None:
        phase_name = 'CALIBRATING' if obj.get('Calibrating', False) else 'MONITORING'
    phase = PHASE_IDS.get(phase_name, PHASE_IDS['MONITORING'])
    try:
        elapsed = int(obj.get('CalibSec', 0) or 0)
    except (TypeError, ValueError):
        elapsed = 0
    elapsed = max(0, min(10, elapsed)) if phase == PHASE_IDS['CALIBRATING'] else 0
    return state, seconds, phase, elapsed


class StatusInbox:
    def __init__(self):
        self.lock = threading.Lock()
        self.data = None
        self.version = 0
        self.last_received = 0.0

    def put(self, state, seconds, phase=4, elapsed=0):
        with self.lock:
            self.data = (state, seconds, phase, elapsed)
            self.version += 1
            self.last_received = time.monotonic()

    def snapshot(self):
        with self.lock:
            return self.data, self.version, self.last_received


def _make_mqtt_client(client_id):
    if hasattr(mqtt, "CallbackAPIVersion"):
        return mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=client_id,
        ), 2
    return mqtt.Client(client_id=client_id), 1


def _rc_failed(reason_code):
    if hasattr(reason_code, "is_failure"):
        return reason_code.is_failure
    return int(reason_code) != 0


class Receiver:
    def __init__(self, host, port, topic, inbox):
        self.host = host
        self.port = port
        self.topic = topic
        self.inbox = inbox

        self.client, api = _make_mqtt_client(f"unoq-study-{os.getpid()}-{int(time.time())}")
        if api == 2:
            self.client.on_connect = self._on_connect_v2
            self.client.on_disconnect = self._on_disconnect_v2
        else:
            self.client.on_connect = self._on_connect_v1
            self.client.on_disconnect = self._on_disconnect_v1
        self.client.on_message = self._on_message
        self.client.reconnect_delay_set(min_delay=1, max_delay=10)

    def _on_connect_v2(self, client, userdata, flags, reason_code, properties):
        self._handle_connect(client, reason_code)

    def _on_disconnect_v2(self, client, userdata, flags, reason_code, properties):
        print(f"[MQTT] Disconnected: {reason_code}", flush=True)

    def _on_connect_v1(self, client, userdata, flags, rc):
        self._handle_connect(client, rc)

    def _on_disconnect_v1(self, client, userdata, rc):
        print(f"[MQTT] Disconnected: {rc}", flush=True)

    def _handle_connect(self, client, reason_code):
        if _rc_failed(reason_code):
            print(f"[MQTT] Connection refused: {reason_code}", flush=True)
            return
        client.subscribe(self.topic, qos=0)
        print(f"[MQTT] Connected {self.host}:{self.port}; topic={self.topic}", flush=True)

    def _on_message(self, client, userdata, message):
        try:
            state, seconds, phase, elapsed = parse_payload(message.payload.decode("utf-8"))
        except (ValueError, UnicodeDecodeError, TypeError) as exc:
            print(f"[MQTT] Ignored invalid message: {exc}", flush=True)
            return

        self.inbox.put(state, seconds, phase, elapsed)
        if phase == PHASE_IDS['CALIBRATING']:
            print(f'[RECV] Calibrating {elapsed}/10s', flush=True)
        elif phase == PHASE_IDS['WAIT_FACE']:
            print('[RECV] Waiting for visible eyes', flush=True)
        else:
            print(f'[RECV] phase={phase} State={state} DozeTime={seconds:.1f}s', flush=True)

    def start(self):
        print(f"[MQTT] Connecting to {self.host}:{self.port}...", flush=True)
        self.client.connect_async(self.host, self.port, keepalive=30)
        self.client.loop_start()

    def stop(self):
        try:
            self.client.disconnect()
        finally:
            self.client.loop_stop()


class CsvLogger:
    HEADER = ["time", "state", "doze_time", "vibration_command"]

    def __init__(self, path):
        self.path = path
        self.last_write = 0.0

    def due(self):
        return time.monotonic() - self.last_write >= CSV_INTERVAL

    def write(self, state, doze_seconds, vibration_on):
        self.last_write = time.monotonic()
        needs_header = not os.path.exists(self.path) or os.path.getsize(self.path) == 0

        try:
            with open(self.path, "a", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)
                if needs_header:
                    writer.writerow(self.HEADER)
                writer.writerow([
                    datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S"),
                    state,
                    f"{doze_seconds:.1f}",
                    "ON" if vibration_on else "OFF",
                ])
                file.flush()
        except OSError as exc:
            print(f"[CSV] Write failed: {exc}", flush=True)
            return

        print(
            f"[CSV] Saved from MCU: {state}, {doze_seconds:.1f}s, "
            f"vibration_command={'ON' if vibration_on else 'OFF'}",
            flush=True,
        )


def _as_number(value, name):
    if isinstance(value, (list, tuple)) and len(value) == 1:
        value = value[0]
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return value
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name}: unexpected Bridge value {value!r}") from exc


class Controller:
    def __init__(self, mode, inbox, csv_path):
        self.mode = mode
        self.inbox = inbox
        self.bridge = None

        self.last_version = -1
        self.last_send = 0.0
        self.last_error = 0.0
        self.stale_reported = False

        self.demo_started = time.monotonic()
        self.demo_version = -1

        self.csv_logger = CsvLogger(csv_path)

    def _read_demo(self):
        period = 27.0
        elapsed = time.monotonic() - self.demo_started
        t = elapsed % period

        if t < 2:
            state, seconds = "Empty", 0.0
        elif t < 6:
            state, seconds = "Study", 0.0
        elif t < 19:
            state, seconds = "Dozzy", t - 6
        elif t < 23:
            state, seconds = "Study", 0.0
        else:
            state, seconds = "Empty", 0.0

        version = int(elapsed * 2)
        if version != self.demo_version:
            self.demo_version = version
            print(f"[DEMO] State={state:<5} DozeTime={seconds:.1f}s", flush=True)

        return (state, seconds, PHASE_IDS["MONITORING"], 0), version, time.monotonic()

    def _get_bridge(self):
        if self.bridge is None:
            from arduino.app_utils import Bridge
            self.bridge = Bridge
        return self.bridge

    def _call(self, method, *params):
        return self._get_bridge().call(method, *params, timeout=BRIDGE_TIMEOUT)

    def _read_mcu_and_log(self):
        state_id = int(_as_number(self._call("read_state_id"), "read_state_id"))
        doze_seconds = float(_as_number(self._call("read_doze_seconds"), "read_doze_seconds"))
        vibration_value = int(_as_number(self._call("read_vibration_command"), "read_vibration_command"))

        if state_id not in ID_STATES:
            raise ValueError(f"Invalid MCU state ID: {state_id}")
        if not math.isfinite(doze_seconds) or doze_seconds < 0:
            raise ValueError(f"Invalid MCU doze time: {doze_seconds}")
        if vibration_value not in (0, 1):
            raise ValueError(f"Invalid MCU vibration value: {vibration_value}")

        self.csv_logger.write(ID_STATES[state_id], doze_seconds, vibration_value == 1)

    def loop(self):
        time.sleep(0.10)

        if self.mode == "demo":
            data, version, last_received = self._read_demo()
        else:
            data, version, last_received = self.inbox.snapshot()

        now = time.monotonic()

        if data is None or now - last_received > STALE_SECONDS:
            if data is not None and not self.stale_reported:
                print("[INFO] No fresh MQTT data for 3 s; pausing MCU updates.", flush=True)
                self.stale_reported = True
            return
        self.stale_reported = False

        if version == self.last_version and now - self.last_send < 1.0:
            return

        state, seconds, phase, elapsed = data

        try:
            ack = self._call("set_study_status", int(STATE_IDS[state]), float(seconds))
            ack = _as_number(ack, "set_study_status") if ack is not None else None
            if ack not in (1, True):
                print(f"[BRIDGE] Unexpected set_study_status response: {ack!r}", flush=True)

            phase_ack = self._call('set_monitor_phase', int(phase), int(elapsed))
            phase_ack = _as_number(phase_ack, 'set_monitor_phase') if phase_ack is not None else None
            if phase_ack not in (1, True):
                print(f'[BRIDGE] Unexpected set_monitor_phase response: {phase_ack!r}', flush=True)

            if self.csv_logger.due():
                self._read_mcu_and_log()

            self.last_version = version
            self.last_send = time.monotonic()

        except Exception as exc:
            if now - self.last_error > 3.0:
                print(f"[BRIDGE/CSV] Failed: {type(exc).__name__}: {exc}", flush=True)
                self.last_error = now


def get_args():
    parser = argparse.ArgumentParser(description="UNO Q MQTT receiver and Linux CSV logger")
    parser.add_argument("--mode", choices=("control", "mqtt-test", "demo"), default=DEFAULT_MODE)
    parser.add_argument("--broker", default=DEFAULT_BROKER)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--topic", default=DEFAULT_TOPIC)
    args, _ = parser.parse_known_args()
    return args


def main():
    args = get_args()
    csv_path = pick_csv_path()
    print(f"[START] Mode={args.mode}", flush=True)
    print(f"[CSV] File path: {csv_path}", flush=True)

    inbox = StatusInbox()
    receiver = None

    if args.mode in ("mqtt-test", "control"):
        broker = resolve_broker(args.broker, args.port)
        receiver = Receiver(broker, args.port, args.topic, inbox)
        receiver.start()

    if args.mode == "mqtt-test":
        print("[INFO] MQTT log-only mode: Bridge and CSV are not used.", flush=True)
        try:
            while True:
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
        finally:
            receiver.stop()
        return

    controller = Controller(args.mode, inbox, csv_path)

    from arduino.app_utils import App

    try:
        App.run(user_loop=controller.loop)
    finally:
        if receiver:
            receiver.stop()


if __name__ == "__main__":
    sys.exit(main())
