// Arduino UNO Q MCU: preserves tested LCD/D9 vibration/CSV getters.
// Adds status display via Linux Bridge: set_monitor_phase(phase, elapsed).
// Phase: 0 waiting, 1 Pi started, 2 waiting for face,
//        3 calibrating, 4 monitoring, 5 camera error.
#include <Wire.h>
#include <DIYables_LCD_I2C.h>
#include <Arduino_RouterBridge.h>
#include <math.h>
#include <string.h>

const int VIBRATION_PIN = 9;
const uint8_t LCD_ADDRESS = 0x27;  // Original working LCD address
DIYables_LCD_I2C lcd(LCD_ADDRESS, 16, 2);

const unsigned long CLEAR_DELAY_MS = 3000UL;
const unsigned long SIGNAL_TIMEOUT_MS = 5000UL;
const unsigned long LCD_PERIOD_MS = 200UL;

int currentState = -1;
float currentDoze = 0.0f;
unsigned long stateBeganMs = 0;
unsigned long lastMessageMs = 0;
unsigned long lastLcdMs = 0;
bool receivedAny = false;
bool motorOn = false;
int currentPhase = 0;
int calibrationElapsed = 0;
char cachedRow0[17] = "";
char cachedRow1[17] = "";

int set_study_status(int stateId, float dozeSeconds) {
  if (stateId < 0 || stateId > 2) return 0;
  if (!isfinite(dozeSeconds) || dozeSeconds < 0.0f) return 0;
  const unsigned long now = millis();
  if (!receivedAny || currentState != stateId) {
    currentState = stateId;
    stateBeganMs = now;
  }
  currentDoze = (stateId == 2) ? dozeSeconds : 0.0f;
  lastMessageMs = now;
  receivedAny = true;
  return 1;
}

int set_monitor_phase(int phaseId, int elapsed) {
  if (phaseId < 0 || phaseId > 5) return 0;
  if (elapsed < 0 || elapsed > 10) return 0;
  currentPhase = phaseId;
  calibrationElapsed = elapsed;
  return 1;
}

// Backward-compatible function for a prior teammate main.py version.
int set_calibration_sec(int elapsed) {
  if (elapsed < 0 || elapsed > 10) return 0;
  currentPhase = (elapsed > 0) ? 3 : 4;
  calibrationElapsed = elapsed;
  return 1;
}

// Linux calls these getters and writes the values to its CSV file.
int read_state_id() { return (currentState < 0) ? 0 : currentState; }
float read_doze_seconds() { return currentDoze; }
int read_vibration_command() { return motorOn ? 1 : 0; }

void renderLine(int row, const char *text, char *cache) {
  char padded[17];
  memset(padded, ' ', 16);
  padded[16] = '\0';
  for (int i = 0; i < 16 && text[i] != '\0'; ++i) padded[i] = text[i];
  if (memcmp(cache, padded, 16) != 0) {
    lcd.setCursor(0, row);
    lcd.print(padded);
    memcpy(cache, padded, 17);
  }
}

void setup() {
  digitalWrite(VIBRATION_PIN, LOW);
  pinMode(VIBRATION_PIN, OUTPUT);
  Wire.begin();
  lcd.init();
  lcd.backlight();
  renderLine(0, "UNO Q Ready", cachedRow0);
  renderLine(1, "Waiting for Pi", cachedRow1);

  Bridge.begin();
  Bridge.provide_safe("set_study_status", set_study_status);
  Bridge.provide_safe("set_monitor_phase", set_monitor_phase);
  Bridge.provide_safe("set_calibration_sec", set_calibration_sec);
  Bridge.provide_safe("read_state_id", read_state_id);
  Bridge.provide_safe("read_doze_seconds", read_doze_seconds);
  Bridge.provide_safe("read_vibration_command", read_vibration_command);
}

void loop() {
  const unsigned long now = millis();
  const bool signalOK = receivedAny && (now - lastMessageMs <= SIGNAL_TIMEOUT_MS);

  // Preserve the team's original vibration threshold and fail-safe timing.
  // Never vibrate during startup/eye calibration.
  bool wantMotor = motorOn;
  if (!signalOK || currentPhase != 4) {
    wantMotor = false;
  } else if (currentState == 2) {
    wantMotor = currentDoze > 10.0f;
  } else if (now - stateBeganMs >= CLEAR_DELAY_MS) {
    wantMotor = false;
  }
  if (wantMotor != motorOn) {
    motorOn = wantMotor;
    digitalWrite(VIBRATION_PIN, motorOn ? HIGH : LOW);
  }

  if (now - lastLcdMs >= LCD_PERIOD_MS) {
    lastLcdMs = now;
    char line0[17];
    char line1[17];
    if (!receivedAny) {
      snprintf(line0, sizeof(line0), "UNO Q Ready");
      snprintf(line1, sizeof(line1), "Waiting for Pi");
    } else if (!signalOK) {
      snprintf(line0, sizeof(line0), "No Pi Signal");
      snprintf(line1, sizeof(line1), "Check Hotspot");
    } else if (currentPhase == 1) {
      snprintf(line0, sizeof(line0), "Raspberry Pi ON");
      snprintf(line1, sizeof(line1), "Camera Starting");
    } else if (currentPhase == 2) {
      snprintf(line0, sizeof(line0), "Look at Camera");
      snprintf(line1, sizeof(line1), "Keep Eyes Open");
    } else if (currentPhase == 3) {
      snprintf(line0, sizeof(line0), "Eye Calibration");
      snprintf(line1, sizeof(line1), "Progress: %02d/10s", calibrationElapsed);
    } else if (currentPhase == 5) {
      snprintf(line0, sizeof(line0), "Camera Error");
      snprintf(line1, sizeof(line1), "Check Camera");
    } else {
      const char *name = (currentState == 0) ? "Empty" :
                         (currentState == 1) ? "Study" : "Dozzy";
      snprintf(line0, sizeof(line0), "State: %s", name);
      float seconds = currentDoze;
      if (seconds > 9999.9f) seconds = 9999.9f;
      snprintf(line1, sizeof(line1), "Doze: %.1fs", (double)seconds);
    }
    renderLine(0, line0, cachedRow0);
    renderLine(1, line1, cachedRow1);
  }
  delay(20);
}
