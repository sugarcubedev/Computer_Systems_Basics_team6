# Study Monitor 무인 실행 + LCD 통합 설치 가이드

기준: Raspberry Pi 5 (Ubuntu 24.04, `rssaem`), UNO Q App Lab, MQTT broker `10.42.0.173:1883`, 핫스팟 SSID `rpi5`.

**대상 코드:** 정상 작동을 확인한 `study_monitor.py v4.1`의 눈 인식 알고리즘은 변경하지 않았습니다. 이 패키지는 부팅, USB 카메라 자동 검색, MQTT 단계 전송, LCD 표시만 추가한 통합판입니다. 실제 두 장비 통합/전원 재부팅 검증은 사용자 장비에서 필요합니다.

## 1. 파일 구성

```text
StudyMonitor_Autostart_Integration/
├── raspberry_pi/
│   ├── study_monitor.py          # v4.1 눈 판정 유지 + SystemStatus/CalibSec 전송
│   ├── install_autostart.sh      # 기존 파일 백업, hotspot/systemd 서비스 설치
│   ├── study-monitor.service
│   ├── rpi5-hotspot.service
│   └── rpi5-hotspot.sh
├── unoq/
│   ├── python/main.py            # 팀원 CSV 코드 유지 + LCD 단계 Bridge 호출
│   ├── python/requirements.txt
│   └── sketch/sketch.ino         # 기존 진동/MCU 조회 함수 유지 + LCD 단계 표시
└── README.md
```

## 2. 적용 순서 (중요: UNO Q 먼저)

### A. UNO Q: 기존 App Lab 프로젝트에서 두 파일 교체

1. 기존 App Lab 프로젝트 전체를 백업하고, 기존 `python/main.py`와 `sketch/sketch.ino`를 이 패키지의 `unoq/python/main.py`, `unoq/sketch/sketch.ino`로 **둘 다 교체**하세요. `python/requirements.txt`에는 `paho-mqtt>=2.1,<3`가 필요합니다.
2. App Lab에서 **Run**을 눌러 MCU 스케치와 Python 앱을 함께 배포하세요. 콘솔에 `[START] Mode=control`, `[MQTT] Connected ...`가 표시되는지 확인합니다. 기존 LCD I2C 주소 `0x27`, D9 진동핀, CSV 게터(`read_state_id`, `read_doze_seconds`, `read_vibration_command`)는 그대로 유지합니다.
3. App Lab의 앱 이름 옆 **▼ > Run at startup**을 활성화하세요. 이 설정은 UNO Q 자체 부팅 자동실행입니다. (공식 안내: https://docs.arduino.cc/software/app-lab/apps/run)

### B. Raspberry Pi: 기존 프로그램 백업 후 자동 실행 설치

GitHub 등으로 패키지의 `raspberry_pi` 폴더를 Raspberry Pi에 복사합니다. 예: `~/Downloads/StudyMonitor_Autostart_Integration/raspberry_pi/`.

**전제**: 기존 `~/mediapipe_test/mqtt_sender.py`와 `face_landmarker.task`, `~/edgeai-venv/bin/python`이 이미 정상 설치되어 있어야 합니다. 설치 스크립트가 이를 확인하고, 기존 `study_monitor.py`를 날짜가 포함된 백업 이름으로 보존합니다.

```bash
cd ~/Downloads/StudyMonitor_Autostart_Integration/raspberry_pi
bash install_autostart.sh
```

> GitHub에서 다른 폴더에 내려받았다면 `cd` 경로만 해당 위치에 맞게 변경하세요. `install_autostart.sh`는 `rssaem` 계정에서 실행해야 합니다. 별도 Python 패키지 설치나 비밀번호 삭제는 필요 없습니다. 설치 중 `sudo` 권한 요청은 1회 있을 수 있으나 **장치 부팅 때는 로그인 비밀번호를 입력하지 않습니다.**

설치 후 즉시 확인:

```bash
sudo systemctl status rpi5-hotspot.service study-monitor.service --no-pager
sudo journalctl -u study-monitor.service -n 60 --no-pager
```

- `enabled / active (running)`이 표시되고, 로그에 `[CAMERA] Capture detected`, `[CALIBRATION]`, `[STATE]`가 보이면 Python 서비스가 동작하는 것입니다.
- USB 카메라가 늦게 나타나면 자동으로 다른 `/dev/video*` 후보를 검사하고 재시도합니다. 20회 검사 후 실패하면 systemd가 8초 뒤 다시 실행합니다.
- **모니터 없이 실행하는 데 `source ~/edgeai-venv/bin/activate`는 필요 없습니다.** 서비스의 `ExecStart`가 가상환경 Python을 직접 실행합니다.
- **Wi-Fi 핫스팟 프로필을 새로 만들지 않습니다.** 현재 `Wi-Fi hotspot`(SSID `rpi5`)을 `nmcli`로 켜므로 기존 DHCP 예약·암호·IP가 유지됩니다.

### C. 전원만 연결하여 부팅 확인

두 장치 전원을 끈 상태에서 UNO Q → 라즈베리파이 순서로 켜면 초기 검증이 쉽습니다. 이후 실제 운영에서는 전원 순서가 달라도 라즈베리파이 서비스가 연결을 재시도합니다.

```bash
sudo reboot
```

사용자 로그인 없이 `rpi5`가 나타나는지, UNO Q LCD가 자동으로 상태를 표시하는지, 눈 감김 10초/눈 뜸 복귀/진동/CSV가 이어지는지 확인합니다. USB 카메라에 의한 부팅 실패는 서비스 로그로 확인할 수 있습니다.

## 3. LCD 출력 의미 (16×2 영문)

| 상황 | 첫째 줄 | 둘째 줄 |
|---|---|---|
| UNO Q 전원 직후, 아직 Pi 메시지 없음 | `UNO Q Ready` | `Waiting for Pi` |
| Pi 프로세스 가동 및 카메라 초기화 | `Raspberry Pi ON` | `Camera Starting` |
| 얼굴·눈을 아직 정상적으로 찾지 못함 | `Look at Camera` | `Keep Eyes Open` |
| 개인별 눈 보정 중 | `Eye Calibration` | `Progress: 03/10s` |
| 정상 측정 중 | `State: Study` | `Doze: 0.0s` |
| 10초 이상 눈 감김 | `State: Dozzy` | `Doze: 10.2s` |
| 라즈베리파이 메시지 5초 중단 | `No Pi Signal` | `Check Hotspot` |
| 카메라 열기 실패가 전달됨 | `Camera Error` | `Check Camera` |

※ MCU 전원 인가를 Pi 전원 인가와 동일시할 수는 없습니다. `Raspberry Pi ON`은 **실제로 Pi 프로그램이 MQTT를 송신했다**는 뜻입니다.

## 4. JSON 통신 규약

기존 필드 `StudentState`, `DozeTime`, `BlinkCount`, `EAR`, `PERCLOS`는 유지합니다. 새 필드는 다음과 같습니다.

```json
{"StudentState":"Empty","DozeTime":0,"SystemStatus":"CALIBRATING","Calibrating":true,"CalibSec":3}
```

`SystemStatus`는 `STARTING`, `WAIT_FACE`, `CALIBRATING`, `MONITORING`, `CAMERA_ERROR` 중 하나이고, `CalibSec`은 0~10 진행 경과 초입니다. MCU의 `set_monitor_phase` RPC가 LCD에 표시합니다. 이 상태 정보는 **UNO Q에서 CSV로 남기는 기존 세 필드**(`state`, `doze_time`, `vibration_command`)를 변경하지 않습니다. 보정 중에도 `Empty,0,OFF`가 CSV에 기록될 수 있습니다.

## 5. 문제 발생 시 확인 / 안전한 원복

```bash
# 서비스 로그
sudo journalctl -u study-monitor.service -n 100 --no-pager
# 핫스팟 상태
nmcli connection show --active
# UNO Q MQTT 브로커까지 닿는지
ping -c 3 10.42.0.173
# 서비스 즉시 중단 (자동실행 등록은 남음)
sudo systemctl stop study-monitor.service
# 자동실행 완전히 끄기
sudo systemctl disable --now study-monitor.service rpi5-hotspot.service
```

기존 `study_monitor_before_lcd_날짜.py` 백업이 `~/mediapipe_test/`에 남습니다. 복구할 때는 서비스를 멈춘 뒤 백업을 `study_monitor.py`로 복사하고, 필요하면 UNO Q의 이전 App Lab 프로젝트를 다시 실행하세요.

**주의:** 이 패키지는 `systemd`나 네트워크 서비스의 부팅 설정만 변경하며 Raspberry Pi 계정 비밀번호를 삭제하지 않습니다. 다른 Wi-Fi에 다시 연결할 때는 hotspot 프로필의 우선순위가 더 높아서 수동으로 `nmcli con up`을 해야 할 수 있습니다. 또한 Arduino App Lab 자체의 `Run at startup`은 **UNO Q에서 직접 활성화**해야 합니다.

## 6. 구현 상태 요약

| 영역 | 원하는 기능 | 현재 구현 상태 | 비고/다음 작업 |
|---|---|---|---|
| Backend (Raspberry Pi) | 10초 개인별 눈 보정, EAR/Mean 필터, 재개방 판정 | 기존 v4.1 로직 보존, 과거 장비 검증 완료 | 새 부팅·MQTT 상태 출력의 실제 장비 검증 필요 |
| Agent / Control | `Study/Dozzy/Empty`, 10초 눈 감김 경고 | 보존 | 고개 각도 판단은 포함하지 않음 |
| Frontend (LCD) | 전원·카메라·실시간 보정·측정 현황 | UNO Q Bridge+MCU 코드 작성, 문법/논리 검사 | App Lab 스케치 빌드 및 실제 16×2 출력 검증 필요 |
| Robot / Devices (UNO Q, Pi) | 자동 핫스팟, 자동 실행, MQTT, 진동, CSV | 서비스/브리지/CSV 연계 파일 제공 | 사용자 장비에서 전원 OFF→ON 무인 부팅 최종 검증 필요 |
