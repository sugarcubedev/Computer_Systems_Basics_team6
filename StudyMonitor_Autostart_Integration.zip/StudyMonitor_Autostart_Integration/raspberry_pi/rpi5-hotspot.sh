#!/usr/bin/env bash
# Use the already-configured rpi5 AP. Never recreate it (preserves Wi-Fi/DHCP reservations).
set -u
PROFILE='Wi-Fi hotspot'
for n in $(seq 1 25); do
  if /usr/bin/nmcli -t -f NAME connection show --active | grep -Fxq "$PROFILE"; then
    echo "[HOTSPOT] Existing $PROFILE is active"
    exit 0
  fi
  if /usr/bin/nmcli -w 12 connection up "$PROFILE"; then
    echo '[HOTSPOT] rpi5 active'
    exit 0
  fi
  echo "[HOTSPOT] Waiting for NetworkManager / Wi-Fi ($n/25)"
  sleep 2
done
echo '[HOTSPOT] Failed to activate saved hotspot profile' >&2
exit 1
