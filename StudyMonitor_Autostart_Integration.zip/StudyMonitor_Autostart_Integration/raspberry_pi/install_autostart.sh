#!/usr/bin/env bash
# Run as user rssaem: bash install_autostart.sh
set -euo pipefail
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOME_DIR="$(getent passwd rssaem | cut -d: -f6)"
TARGET="${HOME_DIR}/mediapipe_test"
if [[ "$(id -un)" != 'rssaem' ]]; then
  echo 'ERROR: log in as rssaem before running this installer.' >&2; exit 1
fi
for needed in "${TARGET}/mqtt_sender.py" "${TARGET}/face_landmarker.task" "${HOME_DIR}/edgeai-venv/bin/python"; do
  if [[ ! -f "$needed" ]]; then echo "Missing: $needed" >&2; exit 1; fi
done
if ! nmcli -g connection.id connection show 'Wi-Fi hotspot' >/dev/null; then
  echo "Missing saved NetworkManager profile 'Wi-Fi hotspot' (SSID must be rpi5)." >&2
  exit 1
fi
if [[ "$(nmcli -g 802-11-wireless.ssid connection show 'Wi-Fi hotspot')" != 'rpi5' ]]; then
  echo 'ERROR: saved hotspot SSID is not rpi5. No changes made.' >&2; exit 1
fi
if [[ -f "${TARGET}/study_monitor.py" ]]; then
  cp -a "${TARGET}/study_monitor.py" "${TARGET}/study_monitor_before_lcd_$(date +%Y%m%d_%H%M%S).py"
fi
install -m 644 "${PACKAGE_DIR}/study_monitor.py" "${TARGET}/study_monitor.py"
"${HOME_DIR}/edgeai-venv/bin/python" -m py_compile "${TARGET}/study_monitor.py"
# Preserve IP, SSID, Wi-Fi password, DHCP reservation and current network profile.
sudo nmcli connection modify 'Wi-Fi hotspot' connection.autoconnect yes connection.autoconnect-priority 100 connection.permissions ''
sudo install -m 755 "${PACKAGE_DIR}/rpi5-hotspot.sh" /usr/local/bin/rpi5-hotspot.sh
sudo install -m 644 "${PACKAGE_DIR}/rpi5-hotspot.service" /etc/systemd/system/rpi5-hotspot.service
sudo install -m 644 "${PACKAGE_DIR}/study-monitor.service" /etc/systemd/system/study-monitor.service
sudo systemctl daemon-reload
sudo systemctl enable rpi5-hotspot.service study-monitor.service
sudo systemctl restart rpi5-hotspot.service
sudo systemctl restart study-monitor.service
printf '\n[INSTALLED] Confirm Raspberry Pi logs and UNO Q receiver before rebooting.\n'
printf '  sudo systemctl status study-monitor.service --no-pager\n'
printf '  sudo journalctl -u study-monitor.service -n 50 --no-pager\n'
