"""UNO Q App Lab: MQTT -> Bridge RPC -> 16x2 LCD and vibration motor.

Modes:
  control     Receive real MQTT and update MCU (App Lab default).
  mqtt-test   Print MQTT messages only; never call Bridge.
  demo        Generate fake states and update MCU; no Raspberry Pi needed.

App Lab: edit DEFAULT_MODE below, then press Run.
UNO Q Linux terminal, MQTT test only:
    python3 python/main.py --mode mqtt-test --broker 127.0.0.1
"""

import argparse
import json
import math
import threading
import time

import paho.mqtt.client as mqtt

# Edit these in App Lab if you cannot supply CLI arguments.
DEFAULT_MODE = "control"       # control | mqtt-test | demo
DEFAULT_BROKER = "192.168.45.142"  # UNO Q Wi-Fi IP from `hostname -I`
DEFAULT_PORT = 1883
DEFAULT_TOPIC = "student/monitor"

STATE_IDS = {"Empty": 0, "Study": 1, "Dozzy": 2}


def parse_payload(payload):
    """Validate Pi message; returns (state string, nonnegative seconds)."""
    obj = json.loads(payload)
    if not isinstance(obj, dict):
        raise ValueError("Payload must be a JSON object")
    state = obj.get("StudentState")
    if state not in STATE_IDS:
        raise ValueError(f"Unknown StudentState: {state!r}")
    try:
        seconds = float(obj.get("DozeTime", 0))
    except (ValueError, TypeError) as exc:
        raise ValueError("DozeTime must be numeric") from exc
    if not math.isfinite(seconds) or seconds < 0:
        raise ValueError("DozeTime must be finite and >= 0")
    if state != "Dozzy":
        seconds = 0.0
    return state, seconds


class StatusInbox:
    def __init__(self):
        self.lock = threading.Lock()
        self.data = None
        self.version = 0
        self.last_received = 0.0

    def put(self, state, seconds):
        with self.lock:
            self.data = (state, seconds)
            self.version += 1
            self.last_received = time.monotonic()

    def snapshot(self):
        with self.lock:
            return self.data, self.version, self.last_received


class Receiver:
    def __init__(self, host, port, topic, inbox):
        self.host, self.port, self.topic = host, port, topic
        self.inbox = inbox
        self.client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=f"unoq-study-{int(time.time())}",
        )
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.client.reconnect_delay_set(min_delay=1, max_delay=10)

    def _on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            client.subscribe(self.topic, qos=0)
            print(f"[MQTT] Connected {self.host}:{self.port}; topic={self.topic}", flush=True)
        else:
            print(f"[MQTT] Connection refused: {reason_code}", flush=True)

    def _on_disconnect(self, client, userdata, flags, reason_code, properties):
        print(f"[MQTT] Disconnected: {reason_code}", flush=True)

    def _on_message(self, client, userdata, message):
        try:
            state, seconds = parse_payload(message.payload.decode("utf-8"))
        except (ValueError, UnicodeDecodeError, TypeError) as exc:
            print(f"[MQTT] Ignored invalid message: {exc}", flush=True)
            return
        self.inbox.put(state, seconds)
        print(f"[RECV] State={state:<5} DozeTime={seconds:.1f}s", flush=True)

    def start(self):
        print(f"[MQTT] Connecting to {self.host}:{self.port}...", flush=True)
        self.client.connect_async(self.host, self.port, keepalive=30)
        self.client.loop_start()

    def stop(self):
        self.client.disconnect()
        self.client.loop_stop()


class Controller:
    def __init__(self, mode, inbox):
        self.mode, self.inbox = mode, inbox
        self.bridge = None
        self.last_version = -1
        self.last_send = 0.0
        self.last_error = 0.0
        self.demo_started = time.monotonic()
        self.demo_version = 0
        self.demo_last_print = -1.0

    def _read_demo(self):
        """Empty 2s -> Study 4s -> Dozzy 13s -> Study 4s -> Empty 4s."""
        period = 27.0
        t = (time.monotonic() - self.demo_started) % period
        if t < 2:
            state, seconds = "Empty", 0.0
        elif t < 6:
            state, seconds = "Study", 0.0
        elif t < 19:
            state, seconds = "Dozzy", t - 6
        elif t < 23:
            state, seconds = "Study", 0.0
        else:
            state, seconds = "Empty", 0.0
        # Demo updates at <= 2Hz; keeps logs manageable.
        version = int((time.monotonic() - self.demo_started) * 2)
        if version != self.demo_version:
            self.demo_version = version
            print(f"[DEMO] State={state:<5} DozeTime={seconds:.1f}s", flush=True)
        return (state, seconds), version, time.monotonic()

    def loop(self):
        time.sleep(0.10)
        if self.mode == "mqtt-test":
            return

        if self.mode == "demo":
            data, version, last_received = self._read_demo()
        else:
            data, version, last_received = self.inbox.snapshot()

        now = time.monotonic()
        # MCU watchdog will stop motor 5s after the last successful RPC.
        # Do not keep feeding the MCU stale MQTT data.
        if data is None or now - last_received > 3.0:
            return
        if version == self.last_version and now - self.last_send < 1.0:
            return

        state, seconds = data
        try:
            if self.bridge is None:
                from arduino.app_utils import Bridge
                self.bridge = Bridge
            ack = self.bridge.call("set_study_status", STATE_IDS[state], float(seconds), timeout=3)
            if ack != 1 and ack is not True:
                print(f"[BRIDGE] Unexpected response: {ack!r}", flush=True)
            self.last_version = version
            self.last_send = time.monotonic()
        except Exception as exc:
            if now - self.last_error > 3.0:
                print(f"[BRIDGE] Failed: {exc}", flush=True)
                self.last_error = now


def get_args():
    parser = argparse.ArgumentParser(description="UNO Q MQTT study-state receiver")
    parser.add_argument("--mode", choices=("control", "mqtt-test", "demo"),
                        default=DEFAULT_MODE)
    parser.add_argument("--broker", default=DEFAULT_BROKER)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--topic", default=DEFAULT_TOPIC)
    return parser.parse_args()


def main():
    args = get_args()
    print(f"[START] Mode={args.mode}", flush=True)
    inbox = StatusInbox()
    receiver = None
    if args.mode in ("mqtt-test", "control"):
        receiver = Receiver(args.broker, args.port, args.topic, inbox)
        receiver.start()
    controller = Controller(args.mode, inbox)

    if args.mode == "mqtt-test":
        print("[INFO] MQTT log-only mode: LCD and motor are NOT commanded.", flush=True)
        # This works in a plain UNO Q Linux terminal (without App Lab).
        try:
            while True:
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
        finally:
            receiver.stop()
        return

    # Bridge / App.run are provided by the Arduino App Lab runtime.
    from arduino.app_utils import App
    try:
        App.run(user_loop=controller.loop)
    finally:
        if receiver:
            receiver.stop()


if __name__ == "__main__":
    main()
